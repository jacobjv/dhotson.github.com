STARTUP SCRIPTS

You can put BeanShell scripts (.bsh files) in the 'startup' subdirectory
of the jEdit install directory or user settings directory, and they will
be run on startup.

See Part III of the user's guide for more information.
